package kr.baeoom.pds.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.baeoom.pds.vo.FilesVO;

public class FilesDao {
	private static FilesDao instance = new FilesDao();
	private FilesDao(){}
	public static FilesDao getInstance(){
		return instance;
	}
	
	// 몇번글의 파일 개수 구하기
	public int getCount(SqlSession sqlSession, int ref){
		return sqlSession.selectOne("files.getCount",ref);
	}
	
	// 몇번글의 파일 목록
	public List<FilesVO> selectByRefList(SqlSession sqlSession, int ref){
		return sqlSession.selectList("files.selectByRefList",ref);
	}
	// 저장하기
	public void insert(SqlSession sqlSession, FilesVO vo){
		sqlSession.insert("files.insert", vo);
	}
	// 다운로드수 증가
	public void incrementCount(SqlSession sqlSession, int idx){
		sqlSession.update("files.incrementCount", idx);
	}
}










