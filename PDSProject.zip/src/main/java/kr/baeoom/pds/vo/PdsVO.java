package kr.baeoom.pds.vo;

import java.util.Date;
import java.util.List;

/*
CREATE TABLE pds(
	idx NUMBER PRIMARY KEY,
	name varchar2(100) NOT NULL,
	password varchar2(100) NOT NULL,
	subject varchar2(100) NOT NULL,
	content varchar2(2000) NOT NULL,
	regdate TIMESTAMP DEFAULT SYSDATE
);
 */
public class PdsVO {
	private int idx;
	private String name;
	private String password;
	private String subject;
	private String content;
	private Date regDate;
	//***************************************
	private List<FilesVO> list; // 추가
	
	public List<FilesVO> getList() {
		return list;
	}
	public void setList(List<FilesVO> list) {
		this.list = list;
	}
	//***************************************
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "PdsVO [idx=" + idx + ", name=" + name + ", password=" + password + ", subject=" + subject + ", content="
				+ content + ", regDate=" + regDate + ", list=" + list + "]";
	}

}
