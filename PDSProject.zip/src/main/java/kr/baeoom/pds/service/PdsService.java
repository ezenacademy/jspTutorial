package kr.baeoom.pds.service;

import org.apache.log4j.Logger;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.LogManager;

import kr.baeoom.jdbc.JDBCUtil;
import kr.baeoom.pds.dao.FilesDao;
import kr.baeoom.pds.dao.PdsDao;
import kr.baeoom.pds.vo.FilesVO;
import kr.baeoom.pds.vo.PageList;
import kr.baeoom.pds.vo.PdsVO;

public class PdsService {

	private static final Logger logger = LogManager.getLogger(PdsService.class.getName());

	private static PdsService instance = new PdsService();
	private PdsService(){}
	public static PdsService getInstance(){
		return instance;
	}
	
	// 1페이지 분량 얻어오는 서비스
	public PageList<PdsVO> selectList(int currentPage, int pageSize, int blockSize){
		logger.debug("selectList 시작 : " + currentPage + ", " + pageSize + ", " + blockSize);
		PageList<PdsVO> pageList = null;
		SqlSession sqlSession = null;
		PdsDao     dao = null;
		try{
			sqlSession = JDBCUtil.getSqlSessionFactory().openSession();
			dao = PdsDao.getInstance();
			
			int totalCount = dao.getCount(sqlSession);
			pageList = new PageList<>(totalCount, currentPage, pageSize, blockSize);
			List<PdsVO> list = dao.selectList(sqlSession, pageList.getStartNo(), pageList.getEndNo());
			pageList.setList(list);
			
			sqlSession.commit();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) sqlSession.close();
		}
		
		
		logger.debug("selectList 종료 : " + pageList.toString());
		return pageList;
	}
	
	public void insert(PdsVO vo, List<FilesVO> list){
		logger.debug("insert 시작 : " + vo.toString());
		SqlSession sqlSession = null;
		PdsDao     dao = null;
		FilesDao   filesDao = null;
		try{
			sqlSession = JDBCUtil.getSqlSessionFactory().openSession();
			dao = PdsDao.getInstance();
			filesDao = FilesDao.getInstance();
			// 글저장
			dao.insert(sqlSession, vo);
			int ref = dao.getMaxIdx(sqlSession);
			// 파일저장
			for(FilesVO v : list){
				v.setRef(ref);
				filesDao.insert(sqlSession, v);
			}
			sqlSession.commit();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) sqlSession.close();
		}
		logger.debug("insert 종료");
	}
	
	public PdsVO selectByIdx(int idx){
		PdsVO pdsVO = null;
		logger.debug("selectByIdx 시작 : " + idx);
		SqlSession sqlSession = null;
		PdsDao     dao = null;
		FilesDao   filesDao = null;
		try{
			sqlSession = JDBCUtil.getSqlSessionFactory().openSession();
			dao = PdsDao.getInstance();
			filesDao = FilesDao.getInstance();
			// 글읽기
			pdsVO = dao.selectByIdx(sqlSession, idx);
			// 파일파일읽기
			List<FilesVO> list = filesDao.selectByRefList(sqlSession, idx);
			pdsVO.setList(list);
			
			sqlSession.commit();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) sqlSession.close();
		}
		logger.debug("selectByIdx 종료 : " + pdsVO);
		return pdsVO;
	}
	// 다운로드수 증가
	public void incrementCount(int idx){
		logger.debug("incrementCount 시작 : " + idx);
		SqlSession sqlSession = null;
		FilesDao   filesDao = null;
		try{
			sqlSession = JDBCUtil.getSqlSessionFactory().openSession();
			filesDao = FilesDao.getInstance();
			
			filesDao.incrementCount(sqlSession, idx);
			
			sqlSession.commit();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			if(sqlSession!=null) sqlSession.close();
		}
		logger.debug("incrementCount 종료");
	}

	
}
