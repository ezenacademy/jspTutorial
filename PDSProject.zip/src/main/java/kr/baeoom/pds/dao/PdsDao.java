package kr.baeoom.pds.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import kr.baeoom.pds.vo.PdsVO;

public class PdsDao {
	private static PdsDao instance = new PdsDao();
	private PdsDao(){}
	public static PdsDao getInstance(){
		return instance;
	}
	
	// 전체 개수 구하기
	public int getCount(SqlSession sqlSession){
		return sqlSession.selectOne("pds.getCount");
	}
	
	// 1페이지 분량의 레코드 받기 
	public List<PdsVO> selectList(SqlSession sqlSession, int startNo, int endNo){
		HashMap<String, Integer> map = new HashMap<>();
		map.put("startNo", startNo);
		map.put("endNo", endNo);
		return sqlSession.selectList("pds.selectList", map);
	}
	
	// 저장하기
	public void insert(SqlSession sqlSession, PdsVO vo){
		sqlSession.insert("pds.insert", vo);
	}
	// 저장한 글의 최대 idx값 얻기
	public int getMaxIdx(SqlSession sqlSession){
		return sqlSession.selectOne("pds.getMaxIdx");
	}
	// 글 1개 가져오기
	public PdsVO selectByIdx(SqlSession sqlSession, int idx){
		return sqlSession.selectOne("pds.selectByIdx",idx);
	}
}








