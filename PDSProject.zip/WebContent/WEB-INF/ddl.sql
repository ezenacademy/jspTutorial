create sequence file_idx_seq;
CREATE TABLE files(
    idx      INT            NOT NULL, 
    ref      INT            NULL, 
    ofile    VARCHAR(45)    NULL, 
    sfile    VARCHAR(45)    NULL, 
    count    INT            NULL, 
    CONSTRAINT FILE_PK PRIMARY KEY (idx)
);

create sequence pds_idx_seq;
CREATE TABLE pds(
    idx         INT             NOT NULL, 
    name        VARCHAR(45)     NULL, 
    password    VARCHAR(45)     NULL, 
    subject     VARCHAR(200)    NULL, 
    content     VARCHAR2(2000) NULL, 
    regDate     TIMESTAMP       NULL, 
    CONSTRAINT PDS_PK PRIMARY KEY (idx)
);
